//
//  MusicListViewModel.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import Combine

class MusicViewModel {

    var apiCallSuccess = PassthroughSubject<Bool,Never>()
    var dataCancellable = Set<AnyCancellable>()
    var playerListPublisher = PassthroughSubject<MusicListResponseModel?, Never>()
    var errorPublisher = PassthroughSubject<String?, Never>()
    
    func fetchMusicListData() {
        getMusicData()
            .receive(on: RunLoop.main)
            .sink { [weak self] completion in
                guard let `self` = self else { return }
                switch completion {
                case .finished:
                    debugPrint("success")
                case .failure(_):
                    debugPrint("failed")
                    self.errorPublisher.send("")
                }
            } receiveValue: { [weak self] result in
                guard let `self` = self else {return}
                self.playerListPublisher.send(result)
            }
            .store(in: &dataCancellable)
        
    }
    
    private func getMusicData() -> AnyPublisher<MusicListResponseModel, Error> {
        return NetworkManager.shared.callAPI(type: .getMusicList(limit: 25))
    }
}

