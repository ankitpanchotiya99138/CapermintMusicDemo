//
//  NetworkManager.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import Combine

class NetworkManager {
    
    static var shared = NetworkManager()
    private init() {}
    
    func bindRequest(type: RequestItemType) -> URLRequest {
        var request = URLRequest(url: type.url)
        request.httpMethod = type.httpMethod
        return request
    }
    
    func callAPI<T: Codable>(type: RequestItemType) -> AnyPublisher<T, Error> {
        let request = bindRequest(type: type)
        return URLSession.shared
            .dataTaskPublisher(for: request)
            .mapError {$0 as Error}
            .tryMap { result in
                guard result.response is HTTPURLResponse else {
                    throw CustomError(title: "Response Error", body: "")
                }
                do {
                    let value = try JSONDecoder().decode(T.self, from: result.data)
                    return value
                } catch {
                    throw CustomError(title: "Decoding Error", body: error.localizedDescription)
                }
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
    
}
