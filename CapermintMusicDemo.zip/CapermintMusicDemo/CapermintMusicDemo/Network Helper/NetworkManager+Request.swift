//
//  NetworkManager+Request.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation

protocol EndPointType {
    var baseURL: String { get }
    var path: String { get }
    var url: URL { get }
    var param: [String: Any]? { get }
    var httpMethod: String { get }
}

enum RequestItemType {
    case getMusicList(limit: Int)
}

extension RequestItemType: EndPointType {
    
    var baseURL: String {
        return "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/"
    }
    
    var path: String {
        switch self {
        case .getMusicList(let limit):
            return "topsongs/limit=\(limit)/json"
        }
    }
    
    
    var url: URL {
        return URL(string: baseURL + path)!
    }
    
    var param: [String : Any]? {
        return nil
    }
    
    var httpMethod: String {
        return "GET"
    }
    
}
