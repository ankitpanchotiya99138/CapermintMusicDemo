//
//  MusicCoordinate.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

class MusicCoordinate: Coordinator {
    
    // MARK: -
    // MARK: - Variables
    var navigationController: UINavigationController
    var window: UIWindow
    
    // MARK: -
    // MARK: - Initializer
    init(navigationController: UINavigationController, window: UIWindow) {
        self.navigationController = navigationController
        self.window = window
    }
    
    func start() {
        let musicListVC = MusicListVC.instantiate(from: .main)
        musicListVC.musicCoordinate = self
        navigationController.viewControllers = [musicListVC]
        window.rootViewController = navigationController
        window.makeKeyAndVisible()
    }
    
    func finish() {
        
    }
    
    func popToViewController() {
        self.navigationController.popViewController(animated: true)
    }
    
    func goToMusicVC(musicListDatas: Entry) {
        let musicDetailVC = MusicDetailVC.instantiate(from: .main)
        musicDetailVC.musicCoordinate = self
        musicDetailVC.musicListData = musicListDatas
        self.navigationController.pushViewController(musicDetailVC, animated: true)
    }
    
}
