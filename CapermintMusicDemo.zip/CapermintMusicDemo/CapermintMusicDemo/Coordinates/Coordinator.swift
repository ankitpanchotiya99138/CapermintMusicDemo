//
//  Coordinator.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

/// Coordinator to manage the flow this method are requird to implement in every coordinator
protocol Coordinator {
    
    var navigationController: UINavigationController { get set}
    func start()
    func finish()
    
}
