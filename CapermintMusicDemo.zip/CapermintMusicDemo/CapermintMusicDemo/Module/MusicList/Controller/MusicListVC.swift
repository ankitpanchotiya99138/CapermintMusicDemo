//
//  ViewController.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import UIKit
import Combine
import CoreData

class MusicListVC: BaseViewController {
    
    // MARK: - Outlet declaration
    @IBOutlet weak var tblMusicList: UITableView!
    @IBOutlet weak var playerListActivityIndicator: UIActivityIndicatorView!
    
    // MARK: - Variable declaration
    private var musicViewModel = MusicViewModel()
    private var cancellable: [AnyCancellable] = []
    private var musicListFeedData: Feed?
    internal var musicCoordinate: MusicCoordinate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialization()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = "Top Songs"
    }
    
}

// MARK: - Initialization functions
extension MusicListVC {
    
    func initialization() {
        bindPlayerListData()
        tblMusicList.register(UINib(nibName: "CellMusicList", bundle: nil), forCellReuseIdentifier: "CellMusicList")
        tblMusicList.rowHeight = UITableView.automaticDimension
        tblMusicList.estimatedRowHeight = 80
        setLoadingScreen()
        retriveData { [weak self] localFeedData in
            guard let `self` = self else { return }
            if localFeedData == nil {
                self.musicViewModel.fetchMusicListData()
            } else {
                self.musicListFeedData = localFeedData
                self.hideIndicator()
                self.tblMusicList.reloadData()
            }
        }
    }
    
    func bindPlayerListData() {
        musicViewModel.errorPublisher
            .receive(on: RunLoop.main)
            .sink(receiveValue: { [weak self] _ in
                guard let `self` = self else {
                    return
                }
                self.hideIndicator()
            })
            .store(in: &cancellable)
        musicViewModel.playerListPublisher
            .receive(on: RunLoop.main)
            .sink(receiveValue: { [weak self] playerListData in
                guard let `self` = self else {
                    return
                }
                self.hideIndicator()
                guard let feedData = playerListData?.feed else {
                    return
                }
                self.musicListFeedData = feedData
                self.setMusicListDataIntoLocal()
                self.tblMusicList.reloadData()
            })
            .store(in: &cancellable)
    }
    
    // MARK: - Set Feed data into core data.
    func setMusicListDataIntoLocal() {
        guard let appDelegates = appDelegate else {
            return
        }
        let manageContext = appDelegates.persistentContainer.viewContext
        let newsEntity = NSEntityDescription.entity(forEntityName: "MusicListData", in: manageContext)
        do {
            let news = NSManagedObject(entity: newsEntity!, insertInto: manageContext)
            let modelNewsData = try? JSONEncoder().encode(self.musicListFeedData)
            let strModelNewsData = String(data: modelNewsData!, encoding: .utf8)
            news.setValue(strModelNewsData, forKey: "musicList")
            try manageContext.save()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    // MARK: - Retrive data from local
    func retriveData(completion: @escaping ((_ localFeedData: Feed?) -> Void)) {
        guard let appDelegates = appDelegate else { return completion(nil) }
        let manageContext = appDelegates.persistentContainer.viewContext
        let fetchRequest = MusicListData.fetchRequest()
        do {
            let results = try manageContext.fetch(fetchRequest)
            guard let strMusicList = results.first?.musicList?.utf8 else {
                return completion(nil)
            }
            let data = Data(strMusicList)
            do {
                let result = try JSONDecoder().decode(Feed.self, from: data)
                completion(result)
            } catch {
                completion(nil)
            }
        } catch {
            completion(nil)
        }
    }
    
}

// MARK: - UITableViewDataSource
extension MusicListVC: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return musicListFeedData?.entry?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cellMusicList = tableView.dequeueReusableCell(withIdentifier: "CellMusicList", for: indexPath) as? CellMusicList else {
            return UITableViewCell()
        }
        if let entry = musicListFeedData?.entry?[indexPath.row] {
            cellMusicList.setUpMusicListData(entry: entry)
        }
        return cellMusicList
    }
    
}

// MARK: - UITableViewDelegate
extension MusicListVC: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let coordinate = musicCoordinate else {
            return
        }
        guard let entry = musicListFeedData?.entry?[indexPath.row] else {
            return
        }
        coordinate.goToMusicVC(musicListDatas: entry)
    }
    
}

// MARK: - Show and hide Activity Loader
extension MusicListVC {
    
    /// Used to show activity indicator and starts animating.
    func setLoadingScreen() {
        self.playerListActivityIndicator.isHidden = false
        self.playerListActivityIndicator.startAnimating()
    }
    
    /// Used to hide activity indicator and stops animating.
    func hideIndicator() {
        DispatchQueue.main.async { [weak self] in
            guard let `self` = self else {
                return
            }
            self.playerListActivityIndicator.stopAnimating()
        }
        self.playerListActivityIndicator.isHidden = true
    }
    
}
