//
//  CellMusicList.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

class CellMusicList: UITableViewCell {
    
    // MARK: - Outlet declaration
    @IBOutlet weak var lblMusicName: UILabel!
    @IBOutlet weak var lblArtistName: UILabel!
    @IBOutlet weak var imgMusic: UIImageView! {
        didSet {
            imgMusic.makeRounded()
        }
    }
    
    // MARK: - Pass entry object and set song list data.
    func setUpMusicListData(entry: Entry) {
        lblMusicName.text = entry.title?.label ?? ""
        lblArtistName.text = entry.imArtist?.label ?? ""
        ImageCache.sharedInstance.imageForUrl(urlString: entry.imImage.first?.label ?? "", completionHandler: { (image, url) in
            if image != nil {
                self.imgMusic.image = image
            }
        })
    }
    
}

