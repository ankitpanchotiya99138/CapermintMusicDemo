//
//  MusicDetailVC.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

class MusicDetailVC: BaseViewController {
    
    // MARK: - Outlet declaration
    @IBOutlet weak var imgMusic: UIImageView! {
        didSet {
            imgMusic.setCornerRadius(10)
        }
    }
    @IBOutlet weak var lblMusicName: UILabel!
    @IBOutlet weak var lblMusicAlbumName: UILabel!
    @IBOutlet weak var lblReleaseDate: UILabel!
    @IBOutlet weak var btnPlay: UIButton! {
        didSet {
            btnPlay.setCornerRadius(10)
        }
    }
    
    // MARK: - Variable declaration
    internal var musicCoordinate: MusicCoordinate?
    var musicListData: Entry?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialization()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = musicListData?.imCollection?.imName?.label ?? ""
    }

}

// MARK: - Set initialization data
extension MusicDetailVC {
    
    func initialization() {
        lblMusicName.text = musicListData?.imName?.label ?? ""
        lblMusicAlbumName.text = musicListData?.imCollection?.imName?.label ?? ""
        lblReleaseDate.text = musicListData?.rights?.label ?? ""
    }
    
}

// MARK: - Action method declaration
extension MusicDetailVC {
    
    @IBAction func tappedOnPlay(_ sender: UIButton) {
        AppleMusicPlayer.shared.playMusic(trackIds: [musicListData?.id?.label ?? ""], startItemId: "", volume: 1.0)
    }
    
}
