//
//  Declaration.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

var appDelegate = UIApplication.shared.delegate as? AppDelegate
