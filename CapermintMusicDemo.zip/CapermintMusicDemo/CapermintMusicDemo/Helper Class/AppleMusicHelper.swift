//
//  AppleMusicHelper.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import MediaPlayer
import MusicKit

class AppleMusicPlayer {
    static var shared = AppleMusicPlayer()
    var musicAuthorizationStatus = MusicAuthorization.currentStatus
    
    static var musicPlayerController = MPMusicPlayerController.applicationMusicPlayer
    var volumeSlider = UISlider()
    
    func playMusic(trackIds: [String], startItemId: String, volume: Float) {
        switch musicAuthorizationStatus {
        case .notDetermined:
            print("notDetermined")
        case .denied:
            print("Please grant Music Albums access to Music in Settings.")
        case .authorized:
            print("Musikkit authorized...")
            Task {
                await self.playTrack(trackIds: trackIds, startItemId: startItemId, volume: volume)
            }
            
        default:
            fatalError("No button should be displayed for current authorization status: \(musicAuthorizationStatus).")
        }
    }
    
    func playTrack(trackIds: [String], startItemId: String, volume: Float) async {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(false)
        } catch let err {
            print("\(err.localizedDescription)")
        }
        
        volumeSlider = await (MPVolumeView().subviews.filter{NSStringFromClass($0.classForCoder) == "MPVolumeSlider"}.first) as! UISlider
        await volumeSlider.setValue(volume, animated: true)
        
        let mpQue = MPMusicPlayerStoreQueueDescriptor.init(storeIDs: trackIds)
        if startItemId == "" {
            if let firstTrackId = trackIds.first {
                mpQue.startItemID = firstTrackId
            }
        } else {
            mpQue.startItemID = startItemId
        }
        
        AppleMusicPlayer.musicPlayerController.stop()
        AppleMusicPlayer.musicPlayerController.setQueue(with: mpQue)
        AppleMusicPlayer.musicPlayerController.prepareToPlay { err in
            AppleMusicPlayer.musicPlayerController.play()
        }
    }
    
    func changeVolume(value: Float) {
        volumeSlider.setValue(value, animated: true)
    }
    
    func playNext() {
        AppleMusicPlayer.musicPlayerController.skipToNextItem()
    }
    
    func playPrevious() {
        AppleMusicPlayer.musicPlayerController.skipToPreviousItem()
    }
    
    func resumeMusic() {
        AppleMusicPlayer.musicPlayerController.play()
    }
    
    func pauseMusic() {
        AppleMusicPlayer.musicPlayerController.pause()
    }
    
    func stopMusic() {
        AppleMusicPlayer.musicPlayerController.stop()
    }
    
    func authorizeMusicKit(trackId: String) {
        
    }
    
}
