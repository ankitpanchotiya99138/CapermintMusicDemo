//
//  MusicPlayerListResponseModel.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation

struct MusicListResponseModel: Codable {
    
    let feed: Feed?
    
    enum CodingKeys: String, CodingKey {
        case feed
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        feed = try values.decodeIfPresent(Feed.self, forKey: .feed)
    }
    
}

struct Feed: Codable {
    let author: Author?
    let entry: [Entry]?
    let updated: Updated?
    let rights: Updated?
    let title: Updated?
    let icon: Updated?
    let link: [Link]?
    let id: Updated?
    
    enum CodingKeys: String, CodingKey {
        case author, entry, updated, rights, title, icon, link, id
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        author = try values.decodeIfPresent(Author.self, forKey: .author)
        entry = try values.decodeIfPresent([Entry].self, forKey: .entry)
        updated = try values.decodeIfPresent(Updated.self, forKey: .updated)
        rights = try values.decodeIfPresent(Updated.self, forKey: .rights)
        title = try values.decodeIfPresent(Updated.self, forKey: .title)
        icon = try values.decodeIfPresent(Updated.self, forKey: .icon)
        link = try values.decodeIfPresent([Link].self, forKey: .link)
        id = try values.decodeIfPresent(Updated.self, forKey: .id)
    }
    
}

struct Author: Codable {
    let name: Updated?
    let uri: Updated?
    
    enum CodingKeys: String, CodingKey {
        case name, uri
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(Updated.self, forKey: .name)
        uri = try values.decodeIfPresent(Updated.self, forKey: .uri)
    }
    
}

struct Entry: Codable {
    let imName: Updated?
    let imImage: [ImPrice]
    let imCollection: ImCollection?
    let imPrice: ImPrice?
    let imContentType: ImContentType?
    let rights: Updated?
    let title: Updated?
    let link: [Link]?
    let id: Updated?
    let imArtist: ImPrice?
    let category: ImPrice?
    let imReleaseDate: ImPrice?
    
    enum CodingKeys: String, CodingKey {
        case imName = "im:name"
        case imImage = "im:image"
        case imCollection = "im:collection"
        case imPrice = "im:price"
        case imContentType = "im:contentType"
        case rights = "rights"
        case title = "title"
        case link = "link"
        case id = "id"
        case imArtist = "im:artist"
        case category = "category"
        case imReleaseDate = "im:releaseDate"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        imName = try values.decodeIfPresent(Updated.self, forKey: .imName)
        imImage = try values.decodeIfPresent([ImPrice].self, forKey: .imImage) ?? []
        imCollection = try values.decodeIfPresent(ImCollection.self, forKey: .imCollection)
        imPrice = try values.decodeIfPresent(ImPrice.self, forKey: .imPrice)
        imContentType = try values.decodeIfPresent(ImContentType.self, forKey: .imContentType)
        rights = try values.decodeIfPresent(Updated.self, forKey: .rights)
        title = try values.decodeIfPresent(Updated.self, forKey: .title)
        link = try values.decodeIfPresent([Link].self, forKey: .link)
        id = try values.decodeIfPresent(Updated.self, forKey: .id)
        imArtist = try values.decodeIfPresent(ImPrice.self, forKey: .imArtist)
        category = try values.decodeIfPresent(ImPrice.self, forKey: .category)
        imReleaseDate = try values.decodeIfPresent(ImPrice.self, forKey: .imReleaseDate)
    }
    
}

struct ImContentType: Codable {
    let attributes: Attributes?
    
    enum CodingKeys: String, CodingKey {
        case attributes
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        attributes = try values.decodeIfPresent(Attributes.self, forKey: .attributes)
    }
    
}

struct ImPrice: Codable {
    let label: String?
    let attributes: Attributes?
    
    enum CodingKeys: String, CodingKey {
        case label, attributes
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        label = try values.decodeIfPresent(String.self, forKey: .label)
        attributes = try values.decodeIfPresent(Attributes.self, forKey: .attributes)
    }
    
}

struct Updated: Codable {
    let label: String
    
    enum CodingKeys: String, CodingKey {
        case label
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        label = try values.decodeIfPresent(String.self, forKey: .label) ?? ""
    }
    
}

struct Link: Codable {
    let attributes: Attributes?
    
    enum CodingKeys: String, CodingKey {
        case attributes
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        attributes = try values.decodeIfPresent(Attributes.self, forKey: .attributes)
    }
    
}

struct ImCollection: Codable {
    let imName: Updated?
    let link: Link?
    let imContentType: ImPrice?
    
    enum CodingKeys: String, CodingKey {
        case imName = "im:name"
        case link = "link"
        case imContentType = "im:contentType"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        imName = try values.decodeIfPresent(Updated.self, forKey: .imName)
        link = try values.decodeIfPresent(Link.self, forKey: .link)
        imContentType = try values.decodeIfPresent(ImPrice.self, forKey: .imContentType)
    }
    
}

struct Attributes: Codable {
    let rel: String
    let type: String
    let href: String
    let height: String
    
    enum CodingKeys: String, CodingKey {
        case rel, type, href, height
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        rel = try values.decodeIfPresent(String.self, forKey: .rel) ?? ""
        type = try values.decodeIfPresent(String.self, forKey: .type) ?? ""
        href = try values.decodeIfPresent(String.self, forKey: .href) ?? ""
        height = try values.decodeIfPresent(String.self, forKey: .height) ?? ""
    }
    
}
