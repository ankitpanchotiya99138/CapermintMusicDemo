//
//  BaseViewController.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

class BaseViewController: UIViewController, Storyboarded {
    
    // MARK: - Variable declaration
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        if #available(iOS 13.0, *) {
            return .darkContent
        } else {
            return .default
            // Fallback on earlier versions
        }
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = ""
        setupNavigationBar()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.title = ""
    }
    
}

// MARK: - To enable native swipe(back) gesture
extension BaseViewController: UIGestureRecognizerDelegate {
    
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
}


// MARK: - Other function declaration
extension BaseViewController {
    
    func setupNavigationBar() {
        navigationController?.navigationBar.backIndicatorImage = UIImage(named: "BackButton")
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "BackButton")
    }
    
}
