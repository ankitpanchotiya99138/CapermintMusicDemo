//
//  UIView+Extension.swift
//  CapermintMusicDemo
//
//  Created by Ankit panchotiya 94 on 27/04/22.
//

import Foundation
import UIKit

extension UIView {
    
    /// Set corner radius
    /// - Parameter cornerRadius: Corner Radius
    func setCornerRadius(_ cornerRadius: CGFloat) {
        layer.cornerRadius = cornerRadius
        self.clipsToBounds = true
    }
    
}
